import pytest
from sqlalchemy import select
from models import User as UserModel


@pytest.mark.asyncio
async def test_register_creates_user(client):
    response = await client.post("/api/auth/register", json={
        "username": "alice",
        "password": "secret123"
    })
    assert response.status_code == 201
    data = response.json()
    assert data["user"]["username"] == "alice"
    assert data["user"]["role"] == "contributor"
    assert "token" in data
    assert isinstance(data["client_access_ids"], list)


@pytest.mark.asyncio
async def test_register_duplicate_username_returns_409(client):
    payload = {"username": "bob", "password": "pw"}
    await client.post("/api/auth/register", json=payload)
    response = await client.post("/api/auth/register", json=payload)
    assert response.status_code == 409


@pytest.mark.asyncio
async def test_login_returns_token(client):
    await client.post("/api/auth/register", json={"username": "carol", "password": "pw"})
    response = await client.post("/api/auth/login", json={"username": "carol", "password": "pw"})
    assert response.status_code == 200
    data = response.json()
    assert "token" in data
    assert data["user"]["username"] == "carol"


@pytest.mark.asyncio
async def test_login_wrong_password_returns_401(client):
    await client.post("/api/auth/register", json={"username": "dave", "password": "correct"})
    response = await client.post("/api/auth/login", json={"username": "dave", "password": "wrong"})
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_login_unknown_user_returns_401(client):
    response = await client.post("/api/auth/login", json={"username": "ghost", "password": "pw"})
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_logout_invalidates_token(client):
    reg = await client.post("/api/auth/register", json={"username": "eve", "password": "pw"})
    token = reg.json()["token"]
    logout_resp = await client.post(
        "/api/auth/logout",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert logout_resp.status_code == 204
    me_resp = await client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert me_resp.status_code == 401


@pytest.mark.asyncio
async def test_me_returns_user_info(client):
    reg = await client.post("/api/auth/register", json={"username": "frank", "password": "pw"})
    token = reg.json()["token"]
    response = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    data = response.json()
    assert data["username"] == "frank"
    assert data["role"] == "contributor"
    assert "client_access_ids" in data


@pytest.mark.asyncio
async def test_change_password_succeeds(client):
    reg = await client.post("/api/auth/register", json={"username": "pwchange", "password": "oldpassword"})
    token = reg.json()["token"]
    response = await client.patch(
        "/api/auth/me/password",
        json={"current_password": "oldpassword", "new_password": "newpassword1", "confirm_password": "newpassword1"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 204
    old_login = await client.post("/api/auth/login", json={"username": "pwchange", "password": "oldpassword"})
    assert old_login.status_code == 401
    new_login = await client.post("/api/auth/login", json={"username": "pwchange", "password": "newpassword1"})
    assert new_login.status_code == 200


@pytest.mark.asyncio
async def test_change_password_mismatch_returns_422(client):
    reg = await client.post("/api/auth/register", json={"username": "pwmismatch", "password": "oldpassword"})
    token = reg.json()["token"]
    response = await client.patch(
        "/api/auth/me/password",
        json={"current_password": "oldpassword", "new_password": "newpassword1", "confirm_password": "differentpassword"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_change_password_too_short_returns_422(client):
    reg = await client.post("/api/auth/register", json={"username": "pwshort", "password": "oldpassword"})
    token = reg.json()["token"]
    response = await client.patch(
        "/api/auth/me/password",
        json={"current_password": "oldpassword", "new_password": "short", "confirm_password": "short"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_change_password_requires_auth(client):
    response = await client.patch(
        "/api/auth/me/password",
        json={"current_password": "x", "new_password": "newpassword1", "confirm_password": "newpassword1"},
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_change_password_wrong_current_returns_400(client):
    reg = await client.post("/api/auth/register", json={"username": "wrongcurrent", "password": "oldpassword"})
    token = reg.json()["token"]
    response = await client.patch(
        "/api/auth/me/password",
        json={"current_password": "WRONG", "new_password": "newpassword1", "confirm_password": "newpassword1"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 400


@pytest.mark.asyncio
async def test_change_password_invalidates_other_tokens(client):
    reg = await client.post("/api/auth/register", json={"username": "invalidatetest", "password": "oldpassword"})
    token_a = reg.json()["token"]
    login = await client.post("/api/auth/login", json={"username": "invalidatetest", "password": "oldpassword"})
    token_b = login.json()["token"]

    await client.patch(
        "/api/auth/me/password",
        json={"current_password": "oldpassword", "new_password": "newpassword1", "confirm_password": "newpassword1"},
        headers={"Authorization": f"Bearer {token_a}"},
    )
    response = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token_b}"})
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_change_password_clears_must_change_password(client, db):
    reg = await client.post("/api/auth/register", json={"username": "mustclear_user", "password": "oldpassword"})
    token = reg.json()["token"]

    result = await db.execute(select(UserModel).where(UserModel.username == "mustclear_user"))
    user_row = result.scalar_one()
    user_row.must_change_password = True
    await db.commit()

    me = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.json()["must_change_password"] is True

    await client.patch(
        "/api/auth/me/password",
        json={"current_password": "oldpassword", "new_password": "newpassword1", "confirm_password": "newpassword1"},
        headers={"Authorization": f"Bearer {token}"},
    )

    me2 = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me2.json()["must_change_password"] is False


@pytest.mark.asyncio
async def test_login_returns_must_change_password(client):
    reg = await client.post("/api/auth/register", json={"username": "mustchange_check", "password": "pw123456"})
    assert reg.json()["must_change_password"] is False


@pytest.mark.asyncio
async def test_me_returns_must_change_password(client):
    reg = await client.post("/api/auth/register", json={"username": "me_mustchange", "password": "pw123456"})
    token = reg.json()["token"]
    me = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.json()["must_change_password"] is False
