from __future__ import annotations
import re
from datetime import datetime
from typing import Any, Literal as PyLiteral, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict, field_validator

SLUG_RE = re.compile(r"^[a-z0-9-]+$")
FILE_EXT_RE = re.compile(r"^\.[A-Za-z0-9]{1,10}$")


# ── Clients ──────────────────────────────────────────────────────────────────

class ClientCreate(BaseModel):
    code: str
    name: str
    description: Optional[str] = None

    @field_validator('code', 'name')
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError('must not be empty')
        return v


class ClientUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class ClientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    code: str
    name: str
    description: Optional[str]
    created_at: datetime


# ── DRL Functions & Imports ───────────────────────────────────────────────────

class DrlFunctionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    rule_type_id: UUID
    name: str
    body: str


class DrlFunctionCreate(BaseModel):
    name: str
    body: str


class DrlFunctionUpdate(BaseModel):
    name: Optional[str] = None
    body: Optional[str] = None


class DrlImportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    rule_type_id: UUID
    statement: str
    kind: str
    is_shared: bool


class DrlImportCreate(BaseModel):
    statement: str
    kind: str = "import"
    is_shared: bool = False


class DrlImportUpdate(BaseModel):
    statement: Optional[str] = None
    kind: Optional[str] = None
    is_shared: Optional[bool] = None


# ── ConditionMeta AST ────────────────────────────────────────────────────────

class ConditionMeta(BaseModel):
    """Top-level wrapper for structured condition AST persisted in condition_meta."""
    schema_version: int = 1
    mode: PyLiteral['builder', 'raw']
    template_key: str
    bindings: list[Any]
    expression: Optional[Any] = None


# ── Rule Types ────────────────────────────────────────────────────────────────

class RuleTypeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    slug: str
    name: str
    pipeline_stage: int
    drl_package: str
    is_system_locked: bool = False
    functions: list[DrlFunctionOut] = []
    imports: list[DrlImportOut] = []
    builder_config: Optional[Any] = None


# ── Rules ─────────────────────────────────────────────────────────────────────

class RuleCreate(BaseModel):
    client_id: UUID
    rule_type_id: UUID
    name: str
    description: Optional[str] = None
    tool: Optional[str] = None
    condition_raw: Optional[str] = None
    action_raw: Optional[str] = None
    condition_meta: Optional[Any] = None
    action_meta: Optional[Any] = None
    enabled: bool = True
    window: Optional[int] = None

    @field_validator('name')
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError('name must not be empty')
        return v


class RuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    tool: Optional[str] = None
    condition_raw: Optional[str] = None
    action_raw: Optional[str] = None
    condition_meta: Optional[Any] = None
    action_meta: Optional[Any] = None
    enabled: Optional[bool] = None
    window: Optional[int] = None


class RuleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    client_id: UUID
    rule_type_id: UUID
    name: str
    description: Optional[str]
    tool: Optional[str]
    condition_raw: Optional[str]
    action_raw: Optional[str]
    condition_meta: Optional[Any]
    action_meta: Optional[Any]
    enabled: bool
    window: Optional[int]
    required_function_names: Optional[list[str]] = None
    required_import_statements: Optional[list[str]] = None
    created_at: datetime
    updated_at: datetime


class RuleCopyRequest(BaseModel):
    target_client_id: UUID


class RuleExportRequest(BaseModel):
    rule_ids: list[UUID]


# ── Deployments ───────────────────────────────────────────────────────────────

class DeploymentCreate(BaseModel):
    client_id: UUID
    version: str
    notes: Optional[str] = None


class DeploymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    client_id: UUID
    version: str
    notes: Optional[str]
    created_at: datetime


# ── DRL Import ────────────────────────────────────────────────────────────────

class ParsedRulePreview(BaseModel):
    name: str
    condition_raw: str
    action_raw: str
    required_function_names: list[str] = []
    required_import_statements: list[str] = []


class ParsedFilePreview(BaseModel):
    filename: str
    package: str
    rule_count: int
    functions: list[dict] = []
    imports: list[dict] = []
    rules: list[ParsedRulePreview]


class DrlFunctionImport(BaseModel):
    name: str
    body: str


class DrlImportImport(BaseModel):
    statement: str
    kind: str = "import"


class ImportConfirmRule(BaseModel):
    client_id: UUID
    rule_type_id: UUID
    name: str
    description: Optional[str] = None
    tool: Optional[str] = None
    condition_raw: str
    action_raw: str
    required_function_names: list[str] = []
    required_import_statements: list[str] = []


class ImportConfirmRequest(BaseModel):
    rule_type_id: UUID
    functions: list[DrlFunctionImport] = []
    imports: list[DrlImportImport] = []
    rules: list[ImportConfirmRule]


# ── Auth ──────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username: str
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    username: str
    role: str


class TokenOut(BaseModel):
    token: str
    user: UserOut
    client_access_ids: list[UUID]
    must_change_password: bool


class MeOut(BaseModel):
    id: UUID
    username: str
    role: str
    client_access_ids: list[UUID]
    must_change_password: bool


class UserWithClientsOut(BaseModel):
    id: UUID
    username: str
    role: str
    client_ids: list[UUID]


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str
    confirm_password: str


class AdminResetPasswordRequest(BaseModel):
    new_password: str


class UserRoleUpdate(BaseModel):
    role: str


class AccessRequestOut(BaseModel):
    id: UUID
    user_id: UUID
    username: str
    client_id: UUID
    client_name: str
    client_code: str
    status: str
    requested_at: datetime
    reviewed_at: Optional[datetime] = None
    reviewed_by_username: Optional[str] = None


# ── Knowledge Base ────────────────────────────────────────────────────────────

class KbCategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    slug: str
    name: str
    sort_order: int


class KnowledgeDocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    client_id: UUID
    kb_category_id: Optional[UUID]
    kb_category: Optional[KbCategoryOut]
    name: str
    description: Optional[str]
    filename: str
    file_size: int
    mime_type: str
    uploaded_by: Optional[UUID]
    created_at: datetime


# ── Script Categories & Cron Jobs ─────────────────────────────────────────────

class ScriptCategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    slug: str
    name: str
    file_extension: str
    mime_type: str
    sort_order: int


class CronJobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    client_id: UUID
    script_category_id: Optional[UUID]
    script_category: Optional[ScriptCategoryOut]
    name: str
    description: Optional[str]
    filename: str
    file_size: int
    mime_type: str
    uploaded_by: Optional[UUID]
    created_at: datetime


# ── Category admin (KB / Scripts) ─────────────────────────────────────────────

class KbCategoryCreate(BaseModel):
    slug: str
    name: str
    sort_order: Optional[int] = None

    @field_validator("slug")
    @classmethod
    def validate_slug(cls, v: str) -> str:
        v = v.strip()
        if not SLUG_RE.match(v):
            raise ValueError("slug must match ^[a-z0-9-]+$")
        return v

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("name must not be empty")
        return v.strip()


class KbCategoryUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: Optional[str] = None
    sort_order: Optional[int] = None

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not v.strip():
            raise ValueError("name must not be empty")
        return v.strip()


class ScriptCategoryCreate(BaseModel):
    slug: str
    name: str
    file_extension: str
    mime_type: str
    sort_order: Optional[int] = None

    @field_validator("slug")
    @classmethod
    def validate_slug(cls, v: str) -> str:
        v = v.strip()
        if not SLUG_RE.match(v):
            raise ValueError("slug must match ^[a-z0-9-]+$")
        return v

    @field_validator("file_extension")
    @classmethod
    def validate_ext(cls, v: str) -> str:
        v = v.strip()
        if not FILE_EXT_RE.match(v):
            raise ValueError("file_extension must start with '.' followed by 1-10 alphanumerics")
        return v

    @field_validator("name", "mime_type")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("must not be empty")
        return v.strip()


class ScriptCategoryUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: Optional[str] = None
    file_extension: Optional[str] = None
    mime_type: Optional[str] = None
    sort_order: Optional[int] = None

    @field_validator("file_extension")
    @classmethod
    def validate_ext(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if not FILE_EXT_RE.match(v):
            raise ValueError("file_extension must start with '.' followed by 1-10 alphanumerics")
        return v

    @field_validator("name", "mime_type")
    @classmethod
    def not_empty(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not v.strip():
            raise ValueError("must not be empty")
        return v.strip()


class CategoryReorderItem(BaseModel):
    id: UUID
    sort_order: int


# ── Rule Type admin ──────────────────────────────────────────────────────────

class RuleTypeCreate(BaseModel):
    slug: str
    name: str
    drl_package: str
    pipeline_stage: Optional[int] = None

    @field_validator("slug")
    @classmethod
    def validate_slug(cls, v: str) -> str:
        v = v.strip()
        if not SLUG_RE.match(v):
            raise ValueError("slug must match ^[a-z0-9-]+$")
        return v

    @field_validator("name", "drl_package")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("must not be empty")
        return v.strip()


class RuleTypeUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: Optional[str] = None
    pipeline_stage: Optional[int] = None

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not v.strip():
            raise ValueError("name must not be empty")
        return v.strip()


class RuleTypeReorderItem(BaseModel):
    id: UUID
    pipeline_stage: int


# ── Automations ───────────────────────────────────────────────────────────────

class AutomationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    category: str
    sub_category: str
    script_name: str
    description: Optional[str]
    created_at: datetime
